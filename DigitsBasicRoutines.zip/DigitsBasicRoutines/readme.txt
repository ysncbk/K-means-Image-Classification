What you find in this directory:

mfeat-pix.txt: the original digit picture dataset, taken from 
http://ftp.ics.uci.edu/pub/ml-repos/machine-learning-databases/mfeat/mfeat-pix

mfeat.info: description of format of mfeat-pix.txt and other relevant info

drawDigitsML.m: a Matlab function to draw pictures from the data vectors

FeatureHistogram.m: a script for training an elementary classifier of zeros versus ones, based on a single feature. 

linClass.m: a script for training a basic linear classifier (unregularized, unoptimized) for the ten digits. 